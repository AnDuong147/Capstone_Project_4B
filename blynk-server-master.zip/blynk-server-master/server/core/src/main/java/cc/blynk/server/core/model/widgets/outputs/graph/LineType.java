package cc.blynk.server.core.model.widgets.outputs.graph;

public enum LineType {

    LINE, DASH

}
