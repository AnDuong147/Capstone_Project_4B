/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 17.05.18.
 */
module http.admin {
    requires cc.blynk.http.core;
    requires cc.blynk.core;
    requires cc.blynk.utils;
    requires io.netty.transport;
    requires org.apache.logging.log4j;
}