/************************************* IMPORTANT SETTINGS ******************************************************************** */

// These definitions are crucial, choose them carefully before running the code. 
#define BLYNK_PRINT stdout              // where you want to print logs of the program running. 

// your preferred server to run the system. Choose either BLYNK_SERVER,
// LOCAL_SERVER (you need to open a terminal and run blynk_server_script file in RPi)
// or PUBLIC_SERVER (you need to open Scaleway.com and turn on the server). 
#define BLYNK_SERVER                    
#define RN_HOME       // Or RN_UNI
// RN location (given)
#ifdef RN_HOME
#define RN_LAT  10.742
#define RN_LONG 106.621
#elif defined RN_UNI
#define RN_LAT  10.729360
#define RN_LONG 106.693730
#endif
/************************************* END OF IMPORTANT SETTINGS ************************************************************** */

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include <wiringPi.h>
#include <wiringSerial.h>
#include "Pi_LoRa_TTL_100.h"
#include "UBX_Neo.h"
#include "Pi_Blynk.h"

UBXMessage ubxMessage;
uint8_t LoRaBuffer[MAX_TX_SIZE];
WidgetMap myMap(V4);

int ser_fd;
volatile RxNodeState RxState = SEND_RQT;       // State of Rx node. 
RET_STATUS STATUS = RET_NOT_INITIAL;           // Status of LoRa module
uint64_t time_now = 0;
const uint16_t waitTimeGPS = 10000;            // ms, wait time for receiving GPS data. 
uint8_t currentBikeID = 1;
bool readNextBike = 0;
uint64_t process_start = 0;

void setup();
void loop();
void Send_RQT_Packet(void);
void Check_Next_Bike(void);

int main(void)
{
	setup();
  while(1)
  {
    loop();
  }	
	return 0;
}

// actions when hardware connected to Blynk server, some initializations on widgets. 
BLYNK_CONNECTED()
{
  // No need to sync any data on RN. We will sync data on server when we need to read some data
  // to control sth. RN only displays data onto the app, so no need for syncing. 
  myMap.clear();
  myMap.location( IndexNameList[0].index,    
                  RN_LAT, RN_LONG,  
                  IndexNameList[0].nameOnMap);
  Blynk.virtualWrite(V0,"RN started");
  Blynk.virtualWrite(V1,"No data");
  Blynk.virtualWrite(V2,"No data");
  Blynk.virtualWrite(V3,"No data");
  // V4 is Map Widget already. 
  Blynk.virtualWrite(V5,"No data");

}  

void setup() 
{
  // struct CFGstruct CFG;
  // struct MVerstruct MVer;


  // // Setting GPIOs 
  // wiringPiSetupGpio();			// Initialize GPIO numbers to BCM number
  // pinMode(AUX_PIN,INPUT);
  // pinMode(M0_PIN, OUTPUT);
  // pinMode(M1_PIN, OUTPUT);
  // pinMode(LED_PIN, OUTPUT);

  // // Initialize serial ports
  // printf("Opening serial port\n");

  // while((ser_fd = serialOpen("/dev/serial0",9600)) < 0)
  // {
	// 	fprintf(stderr,"Unable to open serial device: %s\n",strerror(errno));
	// 	delay(1000);
  // }

  // #ifdef TX_NODE
  // printf("Setting up LoRa module on Bike %d\n",BIKE_ID);
  // #elif defined RX_NODE
  // printf("Setting up LoRa module on Receiver Node\n");
  // #else
  // #error Please define the LoRa module either to transmitter (TX_NODE) or receiver (RX_NODE)
  // #error Definition is located in "E32_TTL_100.h" file
  // #endif

  // // Setup LoRa module 
  // do 
  // {
  // STATUS = LoRaSetup(&CFG,&MVer);
  // } while(STATUS != RET_SUCCESS);  
  // if(STATUS == RET_SUCCESS)
  // {
  //   STATUS = RET_NOT_INITIAL;   // reset flag. 
  //   printf("Setup LoRa OK!!\n");
  // }

    // Initialize Blynk connection
  #ifdef BLYNK_SERVER
  Blynk.begin("YVV2AYfGftcOga3UVkiKoR1ytYn5zta-",serv,port);  // Connect to the default Blynk cloud server
  #elif defined LOCAL_SERVER
  Blynk.begin("fZRlgA5-GUoBSj8Zm9yQB68zDYoewvpL","192.168.137.232",8080); // Connect to local Blynk server
  //Blynk.begin("hxfn0cLfwqIg0DnsDC67f9o5LI_6pQH6","10.0.0.1",8080); // Connect to local Blynk server
  #elif defined PUBLIC_SERVER
  Blynk.begin("j9GcOl4k1ZMXd0VRSoCyAU8Si31wuzoU","163.172.167.173",8080); // Connect to public Blynk server running on Scaleway
  #else
  #error Please define an appropriate server for the system to run on. 
  #error Definition is in main.cpp file. 
  #endif

  // tmr.setInterval(10000,[](){   
  //   if(RxState == IDLE)   RxState = SEND_RQT;
  // });
 
}

void loop() {
  // Run Blynk 
  Blynk.run();
  tmr.run();
  // Upload data to Blynk server
  myMap.location( 1,    // index   
                  10.739581, 106.621517,
                  "Bike_01");
  Blynk.virtualWrite(V1,1.06);   // embed these into device selectors, or remove them. 
  Blynk.virtualWrite(V2,10.739581);
  Blynk.virtualWrite(V3, 106.621517);
  Blynk.virtualWrite(V5,"3D");

    // Upload data to Blynk server
  myMap.location( 2,    // index   
                 10.745081, 106.623445,
                  "Bike_02");
  // Blynk.virtualWrite(V1,0.31);   // embed these into device selectors, or remove them. 
  // Blynk.virtualWrite(V2,10.745081);
  // Blynk.virtualWrite(V3,106.623445);
  // Blynk.virtualWrite(V5,"2D");
// #ifdef RX_NODE

//   switch(RxState)
//   {
//     case IDLE:
//     {
//       /* Point to the next bike in the bike list */
//       Check_Next_Bike();
//       break;
//     }
//     case SEND_RQT:
//     {
//       printf("Sending request message to bike ID = %d\n",currentBikeID);
//       /* Send request packets, if 3 packets are sent for the same bike and there is no repsponse, 
//       switch to notifying operator state. */ 
//       Send_RQT_Packet();
//       break;
//     }

//     case WAIT_GPS_DATA:
//     {
//       uint8_t a = 0;
//       if((a = serialDataAvail(ser_fd)) != sizeof(NAV_POSLLH) 
//       &&  a != sizeof(NAV_STATUS))                                  // Check if a full GPS packet has come.
//       {
//         if(millis() > time_now + waitTimeGPS)                       // if the "waitTimeGPS" has passed. 
//         {
//           printf("Waiting in WAIT_GPS too long, changing to SEND_RQT\n");
//           serialFlush(ser_fd);
//           time_now = millis();
//           RxState = SEND_RQT;                                    // Request data again. 
//         }
//       }     
//       else                                                       // Received a full GPS packet. 
//       {
//         char a[] = "RECEIVED DATA FROM BIKE ";
//         char b[5];
//         snprintf(b,sizeof(b),"%d",currentBikeID);
//         strcat(a,b);
//         Blynk.virtualWrite(V0,a);
//         STATUS = Read_LoRa_Msg((uint8_t*)&ubxMessage,sizeof(ubxMessage)/sizeof(uint8_t));
//         if(STATUS==RET_SUCCESS)
//         {
//           STATUS = RET_NOT_INITIAL;   // reset the flag for the next run
//           blinkLED();
//           int msgType = Find_UBX_Msg_Type();
//           if ( msgType == MT_NAV_POSLLH ) 
//           {
//             RxState = SEND_ACK;
//             time_now = millis();
//             printf("lat: ");      printf("%3.3f",ubxMessage.navPosllh.lat/10000000.0f); 
//             printf("\t");
//             printf("lon: ");      printf("%3.3f",ubxMessage.navPosllh.lon/10000000.0f);
//             printf("\t");
//             printf(" hMSL: ");    printf("%3.3f",ubxMessage.navPosllh.hMSL/10000.0f);
//             printf("\n");
//             // Upload data to Blynk server
//             myMap.location( IndexNameList[currentBikeID].index,    // index   
//                             ubxMessage.navPosllh.lat/10000000.0f,
//                             ubxMessage.navPosllh.lon/10000000.0f,
//                             IndexNameList[currentBikeID].nameOnMap);
//             Blynk.virtualWrite(V1,ubxMessage.navPosllh.hMSL/10000.0f);   // embed these into device selectors, or remove them. 
//             Blynk.virtualWrite(V2,ubxMessage.navPosllh.lat/10000000.0f);
//             Blynk.virtualWrite(V3,ubxMessage.navPosllh.lon/10000000.0f);
//           }
//           else if ( msgType == MT_NAV_STATUS ) {
//             RxState = SEND_ACK;
//             time_now = millis();
//             printf("GPS Fix Type:");    printf("%s",gpsFixMsg[ubxMessage.navStatus.gpsFix]);
//             printf("\n");
//             // Upload data to Blynk server
//             uint8_t a = (uint8_t)ubxMessage.navStatus.gpsFix;
//             if(a > 5) a = 0;    // sometimes GPSFix data received is corrupted, this line limits a from 0 to 5. 
//             Blynk.virtualWrite(V5,gpsFixMsg[a]);
//           }
//           else
//           {
//             RxState = WAIT_GPS_DATA;
//             serialFlush(ser_fd);       
//             time_now = millis();
//             printf("\nInvalid message !!!\n");
//           }
//         }
//       }
//       break;
//     }
//     case SEND_ACK:
//     {
//       if(millis() > time_now + 1000)    // wait 1s later, then send ACK         
//       {
//       time_now = millis();
//       printf("\n\t\tSending ACK msg");
//       Send_LoRa_Msg(currentBikeID,(uint8_t*)ACK_Packet,sizeof(ACK_Packet)/sizeof(uint8_t));
//       //readNextBike = 1;
//       RxState = IDLE;
//       }
//       break;
//     }
//     case NOTIFY_OPERATOR:
//     {
//       printf("\nBEEP BEEP !!!!! NO RESPONSE FROM BIKE %d\n",currentBikeID);
//       char a[] = "NO RESPONSE, BIKE ";
//       char b[5];
//       snprintf(b,sizeof(b),"%d",currentBikeID);
//       strcat(a,b);
//       Blynk.virtualWrite(V0,a);
//       // write blynk functions to notify operator. 
//       //readNextBike = 1;
//       RxState = IDLE;
//       break;
//     }
//     default:
//     {
//       RxState = IDLE;
//       break;
//     }
//   }
// #endif

// }

// void Check_Next_Bike(void)
// {
//   if(readNextBike)
//   {
//     readNextBike = 0;
//     // Point to the next bike in the list "IndexNameList"
//     if(currentBikeID >= ((sizeof(IndexNameList)/sizeof(IndexNameOnMap))-1) || currentBikeID == 0)
//     {
//       currentBikeID = 1;    // reset bike ID to 1 if it exceeds the range. 
//     }
//     else 
//     {
//       currentBikeID++;
//     }
//   }
// }


// void Send_RQT_Packet(void)
// {
//   static uint8_t RQT_count = 0;
//   static uint8_t lastBikeID = 0;
//   // Check the number of times the RN has sent the RQT packet to the same bike. 
//   if(lastBikeID != currentBikeID) 
//   {
//     RQT_count = 0;
//     lastBikeID = currentBikeID;
//   }
//   if(++RQT_count <= 3)
//   {
//     Send_LoRa_Msg(currentBikeID,(uint8_t*)RQT_Packet,sizeof(RQT_Packet)/sizeof(uint8_t));
//     RxState = WAIT_GPS_DATA;
//     serialFlush(ser_fd); 
//     time_now = millis();
//   }
//   else 
//   {
//     RxState = NOTIFY_OPERATOR;
//     RQT_count = 0;
//   }
}