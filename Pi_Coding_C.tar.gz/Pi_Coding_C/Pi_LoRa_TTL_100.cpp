#include <stdint.h>
#include <stdio.h>
#include "Pi_LoRa_TTL_100.h"
#include <wiringPi.h>
#include <wiringSerial.h>


/* Connect LoRa module to 3v3 and GND of Pi, and: 
        Pi                              E32-TTL-100
    *--------*                            *------*
    | IO4(23)     | <------------------> | M0   |
    | IO5(24)     | <------------------> | M1   |
    | IO1(18)     | <------------------> | AUX  |
    | Tx(14)      | <------------------> | Rx   |
    | Rx(15)      | <------------------> | Tx   |
    *--------*                          *------*
*/
const uint8_t RQT_Packet[3] = {'R','Q','T'};
const uint8_t ACK_Packet[3] = {'A','C','K'};
/*==========================AUX ===========================================*/
unsigned char ReadAUX()
{
  unsigned char AUX_HL;
  return AUX_HL =  digitalRead(AUX_PIN);
}

/* Returns if an operation is done (changing mode, done transmitting, done receiving)
 */
RET_STATUS WaitAUX_H()
{
  RET_STATUS STATUS = RET_NOT_INITIAL;

  uint8_t cnt = 0;

  while((ReadAUX()==LOW) && (cnt++<TIME_OUT_SEC))
  {
    printf(".");
    delay(100);
  }

  if(cnt>=TIME_OUT_SEC)
  {
    STATUS = RET_TIMEOUT;
    printf(" TimeOut\n");
  }
  else
  {    
    STATUS = RET_SUCCESS;
    delay(100);   // at least 100ms for the LoRa module to completely change to a new state. 
    printf("\n");
  }

  return STATUS;
}
/*==========================AUX ===========================================*/
//=== Mode Select ===================================+
unsigned char chkModeSame(MODE_TYPE mode)
{
  static MODE_TYPE pre_mode = MODE_4_UNKNOWN;

  if(pre_mode == mode)
  {
    return TRUE;
  }
  else
  {
    printf("\nSwitchMode: from ");  
    printf("0x");
    printf("%X",pre_mode);  
    printf(" to ");  
    printf("0x");
    printf("%X",mode);
    
    pre_mode = mode;
    return FALSE;
  }
}

void SwitchMode(MODE_TYPE mode)
{
  if(!chkModeSame(mode))
  {
    WaitAUX_H();

    switch (mode)
    {
      case MODE_0_NORMAL:
        // Mode 0 | normal operation
        digitalWrite(M0_PIN, LOW);
        digitalWrite(M1_PIN, LOW);
        break;
      case MODE_1_WAKE_UP:
        digitalWrite(M0_PIN, HIGH);
        digitalWrite(M1_PIN, LOW);
        break;
      case MODE_2_POWER_SAVIN:
        digitalWrite(M0_PIN, LOW);
        digitalWrite(M1_PIN, HIGH);
        break;
      case MODE_3_SLEEP:
        // Mode 3 | Setting operation
        digitalWrite(M0_PIN, HIGH);
        digitalWrite(M1_PIN, HIGH);
        break;
      default:
        return ;
    }

    WaitAUX_H();
  }
}
//=== Mode Select ===================================-
//=== Basic cmd =====================================+
void cleanUARTBuf()
{
  serialFlush(ser_fd);  
}

void triple_cmd(SLEEP_MODE_CMD_TYPE Tcmd)
{
  uint8_t CMD[3] = {Tcmd, Tcmd, Tcmd};
  serialPutchar(ser_fd,CMD[0]);     
  serialPutchar(ser_fd,CMD[1]);     
  serialPutchar(ser_fd,CMD[2]);
  WaitAUX_H();  
}

RET_STATUS Module_info(uint8_t* pReadbuf, uint8_t buf_len)
{
  RET_STATUS STATUS = RET_NOT_INITIAL;
  uint8_t Readcnt, idx;

  Readcnt = serialDataAvail(ser_fd);
  printf("\nReceived: %d bytes\n",Readcnt);
  
  if (Readcnt == buf_len)
  {
    STATUS = RET_SUCCESS;
    for(idx=0;idx<buf_len;idx++)
    {
      *(pReadbuf+idx) = serialGetchar(ser_fd);
      printf(" 0x%X", *(pReadbuf+idx));    // print as an ASCII-encoded hexadecimal
    } printf("\n");
  }
  else
  {
    STATUS = RET_DATA_SIZE_NOT_MATCH;
    printf("Data size not match - expected %d bytes, received %d bytes\n",buf_len,Readcnt);  
    cleanUARTBuf();
  }

  return STATUS;
}
//=== Basic cmd =====================================-
//=== Sleep mode cmd ================================+
RET_STATUS Write_CFG_PDS(struct CFGstruct* pCFG)
{
  for(int i = 0;i < sizeof(CFGstruct);i++)
  serialPutchar(ser_fd,*(((uint8_t*)(pCFG)) + i));
  
  WaitAUX_H();

  return RET_SUCCESS;
}

RET_STATUS Read_CFG(struct CFGstruct* pCFG)
{
  RET_STATUS STATUS = RET_NOT_INITIAL;

  //1. read UART buffer.
  cleanUARTBuf();

  //2. send CMD
  triple_cmd(R_CFG);
 
  //3. Receive configure
  STATUS = Module_info((uint8_t *)pCFG, sizeof(CFGstruct));
  if(STATUS == RET_SUCCESS)
  {
  printf("  HEAD:     0x%X",pCFG->HEAD);  
  printf("  ADDH:     0x%X",pCFG->ADDH);  
  printf("  ADDL:     0x%X",pCFG->ADDL);  
  printf("  CHAN:     0x%X",pCFG->CHAN);  
  }

  return STATUS;
}

RET_STATUS Read_module_version(struct MVerstruct* MVer)
{
  RET_STATUS STATUS = RET_NOT_INITIAL;

  //1. read UART buffer.
  cleanUARTBuf();

  //2. send CMD
  triple_cmd(R_MODULE_VERSION);
 

  //3. Receive configure
  STATUS = Module_info((uint8_t *)MVer, sizeof(MVerstruct));
  if(STATUS == RET_SUCCESS)
  {
    printf("  HEAD:     0x%X",MVer->HEAD);  
    printf("  Model:    0x%X",MVer->Model);  
    printf("  Version:  0x%X",MVer->Version);  
    printf("  features: 0x%X",MVer->features);  
  }

  return RET_SUCCESS;
}

void Reset_module()
{
  triple_cmd(W_RESET_MODULE);
  delay(500);             // the LoRa module requires a bit more time after resetting. 
}

RET_STATUS SleepModeCmd(uint8_t CMD, void* pBuff)
{
  RET_STATUS STATUS = RET_NOT_INITIAL;

  printf("\nSleepModeCmd: 0x%X",CMD);  
  WaitAUX_H();

  SwitchMode(MODE_3_SLEEP);

  switch (CMD)
  {
    case W_CFG_PWR_DWN_SAVE:
      printf("Writing permanent configuration");
      STATUS = Write_CFG_PDS((struct CFGstruct* )pBuff);
      break;
    case R_CFG:
    printf("Reading configuration");
      STATUS = Read_CFG((struct CFGstruct* )pBuff);
      break;
    case W_CFG_PWR_DWN_LOSE:
    printf("Writing temporary configuration");
    printf("This function is not implemented yet. Use CMD = W_CFG_PWR_DWN_SAVE to write permanent configuration instead");
    STATUS = RET_NOT_IMPLEMENT;
      break;
    case R_MODULE_VERSION:
      printf("Reading module version");
      STATUS = Read_module_version((struct MVerstruct* )pBuff);
      break;
    case W_RESET_MODULE:
      printf("Resetting module");
      Reset_module();
      STATUS = RET_SUCCESS;
      break;

    default:
      return RET_INVALID_PARAM;
  }
  return STATUS;
}
//=== Sleep mode cmd ================================-

RET_STATUS SettingModule(struct CFGstruct *pCFG)
{
  RET_STATUS STATUS = RET_NOT_INITIAL;

  // Set module address to bike ID 
  pCFG->ADDH = RN_ADDR_H;
  pCFG->ADDL = RN_ADDR_L;
  // Set working frequency
  pCFG->CHAN =LORA_FREQ;        
    // Set air data rate 
  pCFG->SPED_bits.air_bps = LORA_AIR_RATE;
    // Set UART data rate 
  pCFG->SPED_bits.uart_bps = LORA_UART_BAUD;
    // Set UART format 
  pCFG->SPED_bits.uart_fmt = LORA_UART_FMT;
  // Set transmitter power
  pCFG->OPTION_bits.tsmt_pwr = LORA_POWER;
  // Set FEC switch
  pCFG->OPTION_bits.enFWC = ENABLE_FEC;
    // Set wake up time
  pCFG->OPTION_bits.wakeup_time = WAKE_UP_TIME_250;
  // Set pin drive mode
  pCFG->OPTION_bits.drive_mode = PP_DRIVE_MODE;
  // Set transmission mode
  pCFG->OPTION_bits.trsm_mode =LORA_TX_MODE;

  STATUS = SleepModeCmd(W_CFG_PWR_DWN_SAVE, (void* )pCFG);

  SleepModeCmd(W_RESET_MODULE, NULL);

  STATUS = SleepModeCmd(R_CFG, (void* )pCFG);

  return STATUS;
}

RET_STATUS Read_LoRa_Msg(uint8_t *pdatabuf, uint8_t data_lim)
{
  RET_STATUS STATUS = RET_NOT_INITIAL;
  uint8_t idx,data_len;

  SwitchMode(MODE_0_NORMAL);

  data_len = serialDataAvail(ser_fd);
  if (data_len > 0)
  {
    STATUS = RET_SUCCESS;   // at least LoRa module has received sth. 
    printf("\nReceiveMsg: %d bytes\n",data_len); 
    if(data_len <= data_lim)
    {
      for(idx=0;idx<data_len;idx++)
        *(pdatabuf+idx) = serialGetchar(ser_fd);

      for(idx=0;idx<data_len;idx++)
      {
      printf(" 0x%X",*(pdatabuf+idx));
      } 
      printf("\n");
    }
    else
    {
      printf("\nInvalid msg: len > lim");
      printf("\nFlushing UART buffer");
      printf("\n");
      serialFlush(ser_fd);
      STATUS = RET_BUF_TOO_SMALL;   // there is an error. 
    }
  }

  else
  {
    printf("\nNothing received");
    STATUS = RET_NOT_IMPLEMENT;
  }

  return STATUS;
}

// In this function, the return value RET_STATUS is simply for facilitating the 
// function call in UBX_Neo_GPS_Output.ino file. You can see that the status doesn't 
// serve any purpose in this function. 
RET_STATUS Send_LoRa_Msg(uint16_t addr, unsigned char *data, size_t size)
{
  RET_STATUS STATUS = RET_SUCCESS;    // in sending, we always assume that it succeed, as I haven't come up with 
                                      // a method to check it. 

  SwitchMode(MODE_0_NORMAL);

  //TRSM_FP_MODE
  //Send format : ADDH ADDL CHAN DATA_0 DATA_1 DATA_2 ...
  #ifdef RX_NODE
    uint8_t Packet_Header[3] = { ((addr>>8) & 0xFF), (addr & 0xFF), LORA_FREQ};
  #else
    uint8_t Packet_Header[3] = { RN_ADDR_H, RN_ADDR_L, LORA_FREQ}; 
  #endif

  for(int i = 0;i < sizeof(Packet_Header)/sizeof(uint8_t);i++)
  serialPutchar(ser_fd,Packet_Header[i]);
  
  for(int i = 0;i < size;i++)
  serialPutchar(ser_fd,data[i]);
  
  WaitAUX_H();
  
  printf("\nSent to device with addr 0x%X%X",Packet_Header[0],Packet_Header[1]);
  printf(", on channel 0x%X",Packet_Header[2]); 
  printf(",size is %d\n",size); 
  printf("Data is ");
  for(int i = 0;i < size; i++) 
  {
    printf(" 0x%X",data[i]);         
  }
  printf("\n");

  return STATUS;
}

// This function setups the LoRa module according to the SettingModule() function. 
RET_STATUS LoRaSetup(struct CFGstruct *cfg, struct MVerstruct *mver)
{
  RET_STATUS STATUS = RET_NOT_INITIAL;
  // Only when the LoRa module passess all the tests below will the program continues. 
  if((STATUS = SleepModeCmd(W_RESET_MODULE, NULL)) != RET_SUCCESS) {return STATUS;}
  if((STATUS = SleepModeCmd(R_CFG, (void* )cfg)) != RET_SUCCESS) {return STATUS;}
  if((STATUS = SettingModule(cfg)) != RET_SUCCESS) {return STATUS;}
  if((STATUS = SleepModeCmd(R_MODULE_VERSION, (void* )mver)) != RET_SUCCESS) {return STATUS;}

  // Mode 0 | normal operation
  SwitchMode(MODE_0_NORMAL);
  return STATUS;
}

void blinkLED()
{
  static bool LedStatus = LOW;
  digitalWrite(LED_PIN, LedStatus);
  LedStatus = !LedStatus;
}
