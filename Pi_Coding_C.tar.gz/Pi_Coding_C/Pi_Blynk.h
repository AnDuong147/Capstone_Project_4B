#include <BlynkApiWiringPi.h>
#include <BlynkSocket.h>
#include <BlynkWidgets.h>

typedef struct IndexNameOnMap
{
    uint16_t index;
    char nameOnMap[15]; 
} IndexNameOnMap;

extern const IndexNameOnMap IndexNameList[3];
extern BlynkSocket Blynk;
extern const char *auth;
extern const char *serv;
extern uint16_t port;
extern BlynkTimer tmr;

