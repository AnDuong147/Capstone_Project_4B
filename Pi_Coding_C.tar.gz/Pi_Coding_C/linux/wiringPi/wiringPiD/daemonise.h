/*
 * daemonise.h:
 *	Fairly generic "Turn the current process into a daemon" code.
 *
 *	Copyright (c) 2016-2017 Gordon Henderson.
 *********************************************************************************
 */

extern void daemonise (const char *pidFile) ;
