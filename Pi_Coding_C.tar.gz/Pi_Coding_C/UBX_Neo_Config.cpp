/* This file contains configuration data and functions for UBX Neo M8N board. 
 * This version is for Raspberry Pi. 
*/

#include <string.h>
#include <stdint.h>
#include "UBX_Neo.h"
#include <wiringPi.h>
#include <wiringSerial.h>

// GPS Status message
const char* gpsFixMsg[] = {
  "No fix",
  "DR",
  "2D",
  "3D",
  "GPS+DR",
  "Time only"
};

void UBX_Write_Config(int fd,const char* config,uint16_t data_size){
    for(unsigned int i = 0; i < data_size; i++) {                        
    serialPutchar(fd,*(config+i) );
    delay(5); // simulating a 38400baud pace (or less), otherwise commands are not accepted by the device.
  }
}

// The last two bytes of the message is a checksum value, used to confirm that the received payload is valid.
// The procedure used to calculate this is given as pseudo-code in the uBlox manual.
void calcChecksum(unsigned char* CK, int msgSize) {
  memset(CK, 0, 2);
  for (int i = 0; i < msgSize; i++) {
    CK[0] += ((unsigned char*)(&ubxMessage))[i];
    CK[1] += CK[0];
  }
}


// Compares the first two bytes of the ubxMessage struct with a specific message header.
// Returns true if the two bytes match.
unsigned char compareMsgHeader(const unsigned char* msgHeader) {
  unsigned char* ptr = (unsigned char*)(&ubxMessage);
  return (ptr[0] == msgHeader[0]) && (ptr[1] == msgHeader[1]);
}


// Reads in bytes from the GPS module and checks to see if a valid message has been constructed.
// Returns the type of the message found if successful, or MT_NONE if no message was found.
// After a successful return the contents of the ubxMessage union will be valid, for the 
// message type that was found. Note that further calls to this function can invalidate the
// message content, so you must use the obtained values before calling this function again.
int Read_GPS_From_Neo(int fd) 
{
  static int fpos = 0;
  static unsigned char checksum[2];
  static unsigned char currentMsgType = MT_NONE;   // variable holding the type of message. 
  static unsigned char payloadSize = sizeof(UBXMessage);   // Check this 

  while ( serialDataAvail(fd) ) {
     unsigned char c = serialGetchar(fd);
     if ( fpos < 2 ) 
  {
      // For the first two bytes we are simply looking for a match with the UBX header bytes (0xB5,0x62)
      if ( c == UBX_HEADER[fpos] )
        fpos++;
      else
      {
        fpos = 0; // Reset to beginning state.
      }
  }
    else 
    {
      // If we come here then fpos >= 2, which means we have found a match with the UBX_HEADER
      // and we are now reading in the bytes that make up the payload.
      
      // Place the incoming byte into the ubxMessage struct. The position is fpos-2 because
      // the struct does not include the initial two-byte header (UBX_HEADER).
      if ( (fpos-2) < payloadSize )
        ((unsigned char*)(&ubxMessage))[fpos-2] = c;

      fpos++;
      
      if ( fpos == 4 ) {
        // We have just received the second byte of the message type header, 
        // so now we can check to see what kind of message it is.
        if ( compareMsgHeader(NAV_POSLLH_HEADER) ) {
          currentMsgType = MT_NAV_POSLLH;
          payloadSize = sizeof(NAV_POSLLH);
        }
        else if ( compareMsgHeader(NAV_STATUS_HEADER) ) {
          currentMsgType = MT_NAV_STATUS;
          payloadSize = sizeof(NAV_STATUS);
        }
        else {
          // unknown message type, exit
          fpos = 0;
          continue;
        }
      }

      if ( fpos == (payloadSize+2) ) {
        // All payload bytes have now been received, so we can calculate the 
        // expected checksum value to compare with the next two incoming bytes.
        calcChecksum(checksum, payloadSize);
      }
      else if ( fpos == (payloadSize+3) ) {
        // First byte after the payload, ie. first byte of the checksum.
        // Does it match the first byte of the checksum we calculated?
        if ( c != checksum[0] ) {
          // Checksum doesn't match, reset to beginning state and try again.
          fpos = 0; 
        }
      }
      else if ( fpos == (payloadSize+4) ) {
        // Second byte after the payload, ie. second byte of the checksum.
        // Does it match the second byte of the checksum we calculated?
        fpos = 0; // We will reset the state regardless of whether the checksum matches.
        if ( c == checksum[1] ) {
          // Checksum matches, we have a valid message.
          return currentMsgType; 
        }
      }
      else if ( fpos > (payloadSize+4) ) {
        // We have now read more bytes than both the expected payload and checksum 
        // together, so something went wrong. Reset to beginning state and try again.
        fpos = 0;
        return MT_NONE;
      }
    }
  }    
  return MT_NONE;
}

int Find_UBX_Msg_Type(void)
{
  unsigned char currentMsgType = MT_NONE;

  if ( compareMsgHeader(NAV_POSLLH_HEADER) ) {
    currentMsgType = MT_NAV_POSLLH;
  }
  else if ( compareMsgHeader(NAV_STATUS_HEADER) ) {
    currentMsgType = MT_NAV_STATUS;
  }
  else {
    currentMsgType = MT_NONE;
  }
  return currentMsgType;
}
