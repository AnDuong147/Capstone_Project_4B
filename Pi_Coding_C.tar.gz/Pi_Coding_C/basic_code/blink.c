#include <wiringPi.h>

int main(void)
{
 wiringPiSetupGpio();
 pinMode(25,OUTPUT);
while(1)
{
digitalWrite(25,!digitalRead(25));
delay(500);
}
 return  0;
}

