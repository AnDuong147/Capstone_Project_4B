#include "BlynkApiWiringPi.h"
#include <BlynkSocket.h>
#include "Pi_Blynk.h"

BlynkTransportSocket _blynkTransport;
BlynkSocket Blynk(_blynkTransport);

//static const char *auth, *serv;
//static uint16_t port;

const IndexNameOnMap IndexNameList[3] = 
{
    {0,"Base Station"},
    {1,"Bike 001"},
    {2,"Bike 002"}
};


const char *auth = "993fcdc8c28b4619bc752e71efc1766c";
const char *serv = BLYNK_DEFAULT_DOMAIN;
uint16_t port = BLYNK_DEFAULT_PORT;

#include <BlynkWidgets.h>

BlynkTimer tmr;

// This widget is for testing only 
BLYNK_WRITE(V5)
{
    printf("Got a value: %s\n", param[0].asStr());
}
