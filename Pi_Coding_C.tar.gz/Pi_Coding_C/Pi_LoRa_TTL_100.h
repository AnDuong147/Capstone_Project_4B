
#ifndef E32_TTL_100_H_
#define E32_TTL_100_H_

/************************************* SETTINGS******************************************************************** */
/* User definitions: before uploading the code to MCU module, user should revise these settings at least once */
// RX_NODE = Receiver/ base station, TX_NODE = Transmitter node (attached on bike)
#define RX_NODE

#ifdef  TX_NODE
#define BIKE_ID   2UL
#endif

// Pin connection: 
//      E32-TTL-100     |          RPi
//      TX              |           15
//      RX              |           14
#define AUX_PIN	                    18 
#define M0_PIN                      23
#define M1_PIN	                    24
#define LED_PIN                     25

// Configuration data, these data will be written to the LoRa module in SettingModule() function. 
// Device addresses
#define RN_ADDR_H     0x00
#define RN_ADDR_L     0x00

// Working frequency
#define LORA_FREQ       AIR_CHAN_433M

// Transmission mode: either Transpararent mode or Fixed transmission mode (read more in datasheet) 
#define LORA_TX_MODE    TRSM_FP_MODE
// Transmitting power
#define LORA_POWER      TSMT_PWR_20DB

// Air data rate (ADR)
/* The lower the ADR the longer the range, better anti-interfere, but longer trannsmitting time
  ADR must be the same for both modules. */
#define LORA_AIR_RATE   AIR_BPS_2400

// UART baud rate
#define LORA_UART_BAUD  UART_BPS_9600

// UART format 
#define LORA_UART_FMT   UART_FORMAT_8N1
/************************************* END OF SETTINGS******************************************************************** */
#ifdef TX_NODE
typedef enum TxNodeState{
  SLEEP,
  WAIT_FOR_RQT,
  GET_GPS_DATA,
  WAIT_FOR_ACK,
  GSM_WARNING
}TxNodeState;
#elif defined RX_NODE
typedef enum RxNodeState{
  IDLE,
  SEND_RQT,
  WAIT_GPS_DATA,
  SEND_ACK,
  NOTIFY_OPERATOR
}RxNodeState;
#endif


enum RET_STATUS{
  RET_SUCCESS = 0,
  RET_ERROR_UNKNOWN,	/* something shouldn't happened */
  RET_NOT_SUPPORT,
  RET_NOT_IMPLEMENT,
  RET_NOT_INITIAL,
  RET_INVALID_PARAM,
  RET_DATA_SIZE_NOT_MATCH,
  RET_BUF_TOO_SMALL,
  RET_TIMEOUT,
  RET_HW_ERROR,
  RET_BUSY
} ;

enum MODE_TYPE
{
  MODE_0_NORMAL = 0,
  MODE_1_WAKE_UP,
  MODE_2_POWER_SAVIN,
  MODE_3_SLEEP,
  MODE_4_UNKNOWN      // used to initialize the module to correct mode for the first time. 
} ;

//SPED+
typedef enum 
{
  W_CFG_PWR_DWN_SAVE = 0xC0,
  R_CFG              = 0xC1,
  W_CFG_PWR_DWN_LOSE = 0xC2,
  R_MODULE_VERSION   = 0xC3,
  W_RESET_MODULE     = 0xC4
}SLEEP_MODE_CMD_TYPE;

typedef enum 
{
  UART_FORMAT_8N1 = 0x00,  /*no   parity bit one stop*/
  UART_FORMAT_8O1 = 0x01,  /*odd  parity bit one stop*/
  UART_FORMAT_8E1 = 0x02   /*even parity bitone stop*/
}UART_FORMAT_TYPE;

typedef enum 
{
  UART_BPS_1200 = 0x00,
  UART_BPS_9600 = 0x03,
  UART_BPS_115200 = 0x07
}UART_BPS_TYPE;

typedef enum 
{
  AIR_BPS_300   = 0x00,
  AIR_BPS_2400  = 0x02,
  AIR_BPS_19200 = 0x05
}AIR_BPS_TYPE;
//SPED-

//410~441MHz : 410M + CHAN*1M
typedef enum 
{
  AIR_CHAN_410M = 0x00,
  AIR_CHAN_433M = 0x17,
  AIR_CHAN_441M = 0x1F
}AIR_CHAN_TYPE;

//OPTION+
#define TRSM_TT_MODE		0x00	/*Transparent Transmission*/
#define TRSM_FP_MODE		0x01	/*Fixed-point transmission mode*/

#define OD_DRIVE_MODE		0x00
#define PP_DRIVE_MODE		0x01

// Wakeup time, the longer it is, the lower the average receiver current consumption. 
typedef enum 
{
  WAKE_UP_TIME_250  = 0x00,
  WAKE_UP_TIME_1000 = 0x03,
  WAKE_UP_TIME_2000 = 0x07
}WAKE_UP_TIME_TYPE;

#define DISABLE_FEC			0x00
#define ENABLE_FEC			0x01

//Transmit power
typedef enum 
{
  TSMT_PWR_20DB = 0x00,
  TSMT_PWR_17DB = 0x01,
  TSMT_PWR_14DB = 0x02,
  TSMT_PWR_10DB = 0x03
}TSMT_PWR_TYPE;
//OPTION-

#pragma pack(push, 1)
typedef struct SPEDstruct {
  uint8_t air_bps : 3; //bit 0-2
  uint8_t uart_bps: 3; //bit 3-5
  uint8_t uart_fmt: 2; //bit 6-7
}SPEDstruct;

typedef struct OPTIONstruct {
  uint8_t tsmt_pwr    : 2; //bit 0-1
  uint8_t enFWC       : 1; //bit 2
  uint8_t wakeup_time : 3; //bit 3-5
  uint8_t drive_mode  : 1; //bit 6
  uint8_t trsm_mode   : 1; //bit 7
}OPTIONstruct;

typedef struct CFGstruct {
  uint8_t HEAD;
  uint8_t ADDH;
  uint8_t ADDL;
  struct SPEDstruct   SPED_bits;
  uint8_t CHAN;
  struct OPTIONstruct OPTION_bits;
}CFGstruct;

typedef struct MVerstruct {
  uint8_t HEAD;
  uint8_t Model;
  uint8_t Version;
  uint8_t features;
}MVerstruct;
#pragma pack(pop)


/************************************ FACTS ********************************************** */
#define TIME_OUT_SEC	5
#define MAX_TX_SIZE		58
/************************************ END OF FACTS ********************************************** */

// Variable declaration
extern int ser_fd;    // serial file descriptor. 
extern const uint8_t RQT_Packet[3];
extern const uint8_t ACK_Packet[3];
// Function declaration
extern void cleanUARTBuf();
extern RET_STATUS LoRaSetup(struct CFGstruct *cfg, struct MVerstruct *mver);
extern RET_STATUS Read_LoRa_Msg(uint8_t *pdatabuf, uint8_t data_lim);
extern RET_STATUS Send_LoRa_Msg(uint16_t addr, unsigned char *data, size_t size);
extern void blinkLED();
#endif /* E32_TTL_100_H_ */
